from __future__ import annotations

import queue
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from deskew_pdf import (
    DEFAULT_DPI,
    DEFAULT_MAX_ANGLE,
    DEFAULT_STEP,
    PageResult,
    deskew_pages,
    render_pdf_pages,
    save_pdf,
)


class DeskewApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("PDF 기울기 보정")
        self.geometry("720x520")
        self.minsize(620, 460)

        self.input_path = tk.StringVar()
        self.output_path = tk.StringVar()
        self.dpi = tk.StringVar(value=str(DEFAULT_DPI))
        self.manual_angle = tk.StringVar()
        self.status = tk.StringVar(value="PDF 파일을 선택하세요.")
        self.result_queue: queue.Queue[tuple[str, object]] = queue.Queue()

        self._build_ui()

    def _build_ui(self) -> None:
        root = ttk.Frame(self, padding=18)
        root.pack(fill=tk.BOTH, expand=True)
        root.columnconfigure(1, weight=1)
        root.rowconfigure(5, weight=1)

        title = ttk.Label(root, text="스캔 PDF 기울기 보정", font=("", 16, "bold"))
        title.grid(row=0, column=0, columnspan=3, sticky=tk.W, pady=(0, 18))

        ttk.Label(root, text="입력 PDF").grid(row=1, column=0, sticky=tk.W, pady=6)
        ttk.Entry(root, textvariable=self.input_path, state="readonly").grid(
            row=1, column=1, sticky=tk.EW, padx=8
        )
        self.select_button = ttk.Button(root, text="파일 선택", command=self.select_input)
        self.select_button.grid(row=1, column=2, sticky=tk.EW)

        ttk.Label(root, text="저장 위치").grid(row=2, column=0, sticky=tk.W, pady=6)
        ttk.Entry(root, textvariable=self.output_path, state="readonly").grid(
            row=2, column=1, sticky=tk.EW, padx=8
        )
        self.output_button = ttk.Button(root, text="위치 변경", command=self.select_output)
        self.output_button.grid(row=2, column=2, sticky=tk.EW)

        settings = ttk.LabelFrame(root, text="고급 설정", padding=12)
        settings.grid(row=3, column=0, columnspan=3, sticky=tk.EW, pady=(16, 8))
        settings.columnconfigure(1, weight=1)
        settings.columnconfigure(3, weight=1)

        ttk.Label(settings, text="DPI").grid(row=0, column=0, sticky=tk.W)
        ttk.Entry(settings, textvariable=self.dpi, width=10).grid(
            row=0, column=1, sticky=tk.W, padx=(8, 24)
        )
        ttk.Label(settings, text="수동 보정 각도").grid(row=0, column=2, sticky=tk.W)
        ttk.Entry(settings, textvariable=self.manual_angle, width=12).grid(
            row=0, column=3, sticky=tk.W, padx=8
        )

        self.start_button = ttk.Button(
            root,
            text="보정 시작",
            command=self.start_deskew,
            state=tk.DISABLED,
        )
        self.start_button.grid(row=4, column=0, columnspan=3, sticky=tk.EW, pady=(12, 8))

        self.progress = ttk.Progressbar(root, mode="indeterminate")
        self.progress.grid(row=5, column=0, columnspan=3, sticky=tk.EW, pady=(0, 8))

        log_frame = ttk.LabelFrame(root, text="결과", padding=8)
        log_frame.grid(row=6, column=0, columnspan=3, sticky=tk.NSEW)
        log_frame.columnconfigure(0, weight=1)
        log_frame.rowconfigure(0, weight=1)
        root.rowconfigure(6, weight=1)

        self.log = tk.Text(log_frame, height=10, wrap=tk.WORD, state=tk.DISABLED)
        self.log.grid(row=0, column=0, sticky=tk.NSEW)
        scrollbar = ttk.Scrollbar(log_frame, command=self.log.yview)
        scrollbar.grid(row=0, column=1, sticky=tk.NS)
        self.log.configure(yscrollcommand=scrollbar.set)

        status_bar = ttk.Label(root, textvariable=self.status, anchor=tk.W)
        status_bar.grid(row=7, column=0, columnspan=3, sticky=tk.EW, pady=(10, 0))

    def select_input(self) -> None:
        file_path = filedialog.askopenfilename(
            title="보정할 PDF 선택",
            filetypes=(("PDF files", "*.pdf"), ("All files", "*.*")),
        )
        if not file_path:
            return

        input_path = Path(file_path)
        self.input_path.set(str(input_path))
        self.output_path.set(str(default_output_path(input_path)))
        self.start_button.configure(state=tk.NORMAL)
        self.status.set("보정할 준비가 되었습니다.")
        self._set_log("")

    def select_output(self) -> None:
        initial = Path(self.output_path.get()) if self.output_path.get() else None
        file_path = filedialog.asksaveasfilename(
            title="저장 위치 선택",
            defaultextension=".pdf",
            initialdir=str(initial.parent) if initial else "",
            initialfile=initial.name if initial else "",
            filetypes=(("PDF files", "*.pdf"), ("All files", "*.*")),
        )
        if file_path:
            self.output_path.set(file_path)

    def start_deskew(self) -> None:
        try:
            input_path, output_path, dpi, manual_angle = self._read_inputs()
        except ValueError as exc:
            messagebox.showerror("입력 확인", str(exc))
            return

        self._set_busy(True)
        self.status.set("PDF를 보정하는 중입니다...")
        self._set_log("작업을 시작했습니다.\n")

        worker = threading.Thread(
            target=self._run_deskew,
            args=(input_path, output_path, dpi, manual_angle),
            daemon=True,
        )
        worker.start()
        self.after(100, self._poll_result)

    def _read_inputs(self) -> tuple[Path, Path, int, float | None]:
        input_text = self.input_path.get().strip()
        output_text = self.output_path.get().strip()
        if not input_text:
            raise ValueError("입력 PDF를 선택하세요.")
        if not output_text:
            raise ValueError("저장 위치를 선택하세요.")

        input_path = Path(input_text)
        output_path = Path(output_text)
        if not input_path.exists():
            raise ValueError("입력 PDF 파일을 찾을 수 없습니다.")

        try:
            dpi = int(self.dpi.get().strip())
        except ValueError as exc:
            raise ValueError("DPI는 숫자로 입력하세요.") from exc
        if dpi < 72 or dpi > 600:
            raise ValueError("DPI는 72에서 600 사이로 입력하세요.")

        angle_text = self.manual_angle.get().strip()
        manual_angle = None
        if angle_text:
            try:
                manual_angle = float(angle_text)
            except ValueError as exc:
                raise ValueError("수동 보정 각도는 숫자로 입력하세요.") from exc

        return input_path, output_path, dpi, manual_angle

    def _run_deskew(
        self,
        input_path: Path,
        output_path: Path,
        dpi: int,
        manual_angle: float | None,
    ) -> None:
        try:
            pages = render_pdf_pages(input_path, dpi=dpi)
            fixed_pages, results = deskew_pages(
                pages,
                manual_angle=manual_angle,
                max_angle=DEFAULT_MAX_ANGLE,
                step=DEFAULT_STEP,
            )
            save_pdf(fixed_pages, output_path, dpi=dpi)
        except Exception as exc:
            self.result_queue.put(("error", exc))
            return

        self.result_queue.put(("success", (output_path, results)))

    def _poll_result(self) -> None:
        try:
            kind, payload = self.result_queue.get_nowait()
        except queue.Empty:
            self.after(100, self._poll_result)
            return

        self._set_busy(False)
        if kind == "error":
            self.status.set("작업에 실패했습니다.")
            messagebox.showerror("오류", str(payload))
            self._append_log(f"오류: {payload}\n")
            return

        output_path, results = payload
        self.status.set("보정이 완료되었습니다.")
        self._show_success(output_path, results)

    def _show_success(self, output_path: Path, results: list[PageResult]) -> None:
        lines = [f"저장 완료: {output_path}", ""]
        lines.extend(
            f"{result.page_number}페이지: {result.correction_angle:+.2f}도 보정"
            for result in results
        )
        self._set_log("\n".join(lines))
        messagebox.showinfo("완료", f"보정된 PDF를 저장했습니다.\n{output_path}")

    def _set_busy(self, busy: bool) -> None:
        state = tk.DISABLED if busy else tk.NORMAL
        self.select_button.configure(state=state)
        self.output_button.configure(state=state)
        self.start_button.configure(state=state if self.input_path.get() else tk.DISABLED)
        if busy:
            self.progress.start(12)
        else:
            self.progress.stop()

    def _set_log(self, text: str) -> None:
        self.log.configure(state=tk.NORMAL)
        self.log.delete("1.0", tk.END)
        self.log.insert(tk.END, text)
        self.log.configure(state=tk.DISABLED)

    def _append_log(self, text: str) -> None:
        self.log.configure(state=tk.NORMAL)
        self.log.insert(tk.END, text)
        self.log.configure(state=tk.DISABLED)


def default_output_path(input_path: Path) -> Path:
    return input_path.with_name(f"{input_path.stem}_deskewed.pdf")


def main() -> None:
    app = DeskewApp()
    app.mainloop()


if __name__ == "__main__":
    main()
